# My Package
This library was created as an example of how to publish python packages

# How to install